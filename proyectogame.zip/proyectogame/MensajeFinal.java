/**
    Responsable por mostrar el mensaje cuando el usuario choca la nave.
*/
import greenfoot.*;  // Importa las clases de Greenfoot

public class MensajeFinal extends Actor {
    
    public MensajeFinal(String texto) {
        setImage(new GreenfootImage(texto, 24, Color.WHITE, Color.BLACK));
    }
}