/**
 * La clase Nave representa una nave en el mundo de Greenfoot que implementa la interfaz Acciones.
 * Cada nave tiene una cantidad de pasajeros y un nombre de piloto asociados.
 * Esta clase permite mover la nave utilizando las teclas direccionales y maneja las colisiones con las aves.
 * Cuando la nave colisiona con un ave, se reproduce un sonido de impacto y el juego se detiene.
 */


import greenfoot.*;  // Importa las clases de Greenfoot

public class Nave extends Actor implements Acciones {
    private int cantidadPasajeros;
    private String nombrePiloto;
    private Tablero tablero; // Referencia al tablero para actualizar el puntaje
    private boolean soundPlayed = false; // Para controlar la reproducción del sonido
 

    // Constructor
        public Nave(int cantidadPasajeros, String nombrePiloto, Tablero tablero) {
            this.cantidadPasajeros = cantidadPasajeros;
            this.nombrePiloto = nombrePiloto;
            this.tablero = tablero;

        }

    // Accesores y mutadores
    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

    public void setCantidadPasajeros(int cantidadPasajeros) {
        this.cantidadPasajeros = cantidadPasajeros;
    }

    public String getNombrePiloto() {
        return nombrePiloto;
    }

    public void setNombrePiloto(String nombrePiloto) {
        this.nombrePiloto = nombrePiloto;
    }

    // Implementación de los métodos de la interfaz Acciones
    @Override
    public void cambiar() {
        // Aquí va la lógica para cambiar, si es necesario
    }

    @Override
    public void colisionar() {
        if (isTouching(Ave.class)) {
            System.out.println("El juego ha terminado porque la nave tocó un ave.");
        
            if (!soundPlayed) {
                GreenfootSound sound = new GreenfootSound("impact.mp3");
                sound.play();
                soundPlayed = true;
            }
             getWorld().addObject(new MensajeFinal("El juego termina, chocaste un insecto."), getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            removeTouching(Ave.class); // Elimina el ave con la que colisionó
            getWorld().removeObject(this); // Elimina esta nave
            Greenfoot.stop(); // Detiene el juego
        }
    }

    // Método act
    public void act() {
         
            mover();
            cambiar();
            colisionar();    
        
    }
    

    // Método para mover la nave con las teclas
  private void mover() {
    boolean seMovio = false; // Bandera para verificar si la nave se movió

    if (Greenfoot.isKeyDown("a")) {
        setLocation(getX() - 10, getY());
        seMovio = true;
    }
    if (Greenfoot.isKeyDown("d")) {
        setLocation(getX() + 10, getY());
        seMovio = true;
    }
    if (Greenfoot.isKeyDown("w")) {
        setLocation(getX(), getY() - 10);
        seMovio = true;
    }
    if (Greenfoot.isKeyDown("s")) {
        setLocation(getX(), getY() + 10);
        seMovio = true;
    }

    // Si la nave se movió, entonces verifica la distancia
    if (seMovio) {
        verificarDistancia();
    }
}
    
        private void verificarDistancia() {
        tablero.addPuntos(1);
    }

 
    
}