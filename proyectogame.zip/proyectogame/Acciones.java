import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Interfaz que define métodos para acciones genéricas que pueden ser implementadas por diferentes clases.
 * Estos métodos incluyen la capacidad de cambiar alguna característica o estado, así como manejar colisiones.
 */

public interface Acciones {
    void cambiar();
    void colisionar();
}
