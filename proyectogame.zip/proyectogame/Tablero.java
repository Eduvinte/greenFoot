import greenfoot.*;  // Importa las clases de Greenfoot

public class Tablero extends Actor {
    private int puntaje = 0; // Puntaje inicial
    private boolean juegoTerminado = false; // Indica si el juego ha terminado

    public void addPuntos(int puntos) {
        puntaje += puntos;
        if (puntaje >= 150 && !juegoTerminado) {
            juegoTerminado = true; // Marca el juego como terminado
            Greenfoot.stop();
        }
    }

    public void act() {
        if (!juegoTerminado) {
            // Muestra el puntaje actual mientras el juego está en curso
            setImage(new GreenfootImage("Puntaje: " + puntaje, 20, Color.WHITE, Color.BLACK));
        } else {
            // Muestra el mensaje final cuando el juego termina
            setImage(new GreenfootImage("El juego termina porque alcanzaste 150 puntos.", 20, Color.WHITE, Color.BLACK));
        }
    }
}