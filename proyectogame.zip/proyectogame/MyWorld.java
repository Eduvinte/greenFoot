import greenfoot.*;  // Importa las clases necesarias de Greenfoot

/**
 * La clase MyWorld extiende de World y configura el entorno inicial del juego.
 * Esta clase se encarga de inicializar el mundo con un tamaño específico,
 * solicitar información al usuario y colocar los objetos iniciales en el mundo.
 * 
 * El mundo creado tiene un tamaño de 600x400 celdas, con cada celda de tamaño 1x1.
 */
public class MyWorld extends World
{
    /**
     * Constructor para objetos de la clase MyWorld.
     * Este constructor llama a super para establecer las dimensiones del mundo
     * y luego invoca el método prepare para preparar el mundo para el inicio del juego.
     */
    public MyWorld()
    {
        super(600, 400, 1); // Llama al constructor de la clase padre World
        prepare(); // Prepara el mundo para el inicio del juego
    }

    /**
     * Prepara el mundo para el inicio del programa.
     * Este método se encarga de crear y añadir los objetos iniciales al mundo.
     * Solicita al usuario que ingrese el nombre del piloto y la cantidad de pasajeros,
     * crea una instancia de la clase Tablero, y añade objetos de las clases Nave y Ave
     * en posiciones específicas dentro del mundo.
     */
    private void prepare()
    {
        // Solicita al usuario que ingrese el nombre del piloto y la cantidad de pasajeros
        String nombrePiloto = Greenfoot.ask("Ingrese el nombre del piloto:");
        int cantidadPasajeros = Integer.parseInt(Greenfoot.ask("Ingrese la cantidad de pasajeros:"));
        
        // Crea una instancia de Tablero y añade objetos de Nave y Ave al mundo
        Tablero tablero = new Tablero();
        Nave nave =  new  Nave(cantidadPasajeros, nombrePiloto, tablero);
        addObject(nave, 74, 104);
        nave.setLocation(100, 100);
        addObject(tablero, 300, 50);
        InfoDisplay infoDisplay = new InfoDisplay("Piloto: " + nombrePiloto + " - Pasajeros: " + cantidadPasajeros);
        addObject(infoDisplay, 300, 25); // Ajusta la posición según necesites
        // Añade tres objetos de la clase Ave en diferentes posiciones
        Ave ave = new Ave(5);
        addObject(ave,472,79);
        Ave ave2 = new Ave(6);
        addObject(ave2,392,253);
        Ave ave3 = new Ave(6);
        addObject(ave3,511,339);
    }
}