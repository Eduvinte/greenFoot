import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Ave representa un ave en el mundo de Greenfoot.
 * Cada ave tiene una edad expresada en meses.
 */
public class Ave extends Actor
{
    private int edad_en_meses; // Edad de la ave en meses

    /**
     * Constructor para objetos de clase Ave.
     * @param edad_en_meses La edad inicial de la ave en meses.
     */
    public Ave(int edad_en_meses) {
        this.edad_en_meses = edad_en_meses;
    }

    /**
     * Actúa - hace lo que Ave quiera hacer. Este método se llama siempre
     * que se presiona el botón 'Act' o 'Run'.
     */
    public void act() {
        // Código de acción aquí.
    }

    /**
     * Obtiene la edad de la ave en meses.
     * @return La edad de la ave en meses.
     */
    public int getEdadEnMeses() {
        return edad_en_meses;
    }
    
}
