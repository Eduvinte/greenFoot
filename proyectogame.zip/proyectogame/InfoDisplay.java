/**
    Responsable por mostrar el mensaje cuando el usuario escriba el nombre del piloto 
    y la cantidad de tripulantes.
*/

import greenfoot.*;  // Importa las clases de Greenfoot
//import java.awt.Color;

public class InfoDisplay extends Actor {
    public InfoDisplay(String texto) {
        updateText(texto);
    }

    public void updateText(String texto) {
        GreenfootImage image = new GreenfootImage(texto, 24, Color.WHITE, new Color(0, 0, 0, 0));
        setImage(image);
    }
}